package org.example.models;

public enum CachePolicyType {
  LRU,
  LFU
}
